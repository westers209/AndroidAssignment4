package com.example.bottomsheet.model;

import java.util.List;

public class ParkingPojo {

    public List<ParkingInfo> data;

}
