package com.example.bottomsheet.model;

public class ParkingInfo {

    private int id;
    private int lat;
    private int lng;
    private String name;
    private int cost_per_minute;
    private int max_reserve_time_mins;
    private int min_reserve_time_mins;
    private boolean is_reserved;
    private String reserved_until;

    public int getId(){
        return id;
    }

    public void setId(){
        this.id=id;
    }

    public int getLat(){
        return lat;
    }

    public void setLat(){
        this.lat=lat;
    }

    public int getLng(){
        return lng;
    }

    public void setLng(){
        this.lng=lng;
    }

    public String getName(){
        return name;
    }

    public void setName(){
        this.name=name;
    }

    public int getCost_per_minute(){
        return cost_per_minute;
    }

    public void setCost_per_minute(){
        this.cost_per_minute=cost_per_minute;
    }

    public int getMax_reserve_time_mins(){
        return max_reserve_time_mins;
    }

    public void setMax_reserve_time_mins(){
        this.max_reserve_time_mins=max_reserve_time_mins;
    }

    public int getMin_reserve_time_mins(){
        return min_reserve_time_mins;
    }

    public void setMin_reserve_time_mins(){
        this.min_reserve_time_mins=min_reserve_time_mins;
    }

    public boolean getIs_reserved(){
        return is_reserved;
    }

    public void setIs_reserved(){
        this.is_reserved=is_reserved;
    }

    public String getReserved_until(){
        return reserved_until;
    }

    public void setReserved_until(){
        this.reserved_until=reserved_until;
    }

}
