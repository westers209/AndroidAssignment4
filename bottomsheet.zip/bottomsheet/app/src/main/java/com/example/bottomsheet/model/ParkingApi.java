package com.example.bottomsheet.model;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ParkingApi {

    @GET("/api/v1/parkinglocations?format=api")
    Call<ParkingPojo> getReservation();

    @FormUrlEncoded
    @POST("/api/v1/parkinglocations?format=api")
    public void reserve(@Field("id") int id,
                        @Field("lat") int lat,
                        @Field("lng") int lng,
                        @Field("name") String name,
                        @Field("cost_per_minute") int cost_per_minute,
                        @Field("max_reserve_time_mins") int max_reserve_time_mins,
                        @Field("min_reserve_time_mins") int min_reserve_time_mins,
                        @Field("is_reserved") boolean is_reserved,
                        @Field("reserved_until") String reserved_until);
}
