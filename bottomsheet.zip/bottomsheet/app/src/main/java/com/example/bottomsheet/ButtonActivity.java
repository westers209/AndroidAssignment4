package com.example.bottomsheet;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Toast;

import com.example.bottomsheet.model.ParkingApi;
import com.example.bottomsheet.model.ParkingPojo;

import java.sql.Time;
import java.text.DateFormat;

import retrofit2.Call;

public class ButtonActivity extends AppCompatActivity{

    EditText etDate;
    EditText etLocation;
    EditText etTime;
    SeekBar sbReserveFor;
    String locationValue;
    String dateValue;
    String timeValue;
    Button btn_search;
    ParkingApi api;
    int reserveTimeValue;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bottom_sheet);

        etDate = findViewById(R.id.et_date);
        etLocation = findViewById(R.id.et_location);
        etTime = findViewById(R.id.et_time);
        sbReserveFor = findViewById(R.id.sb_reserve_for);
        btn_search = findViewById(R.id.btn_search);

        locationValue = etLocation.getText().toString();
        dateValue = etDate.getText().toString();
        timeValue = etTime.getText().toString();

        sbReserveFor.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int reservedTime = 0;

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                reservedTime = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                reserveTimeValue = reservedTime;
            }
        });

        btn_search.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                api.getReservation();
            }
        });

    }

}
