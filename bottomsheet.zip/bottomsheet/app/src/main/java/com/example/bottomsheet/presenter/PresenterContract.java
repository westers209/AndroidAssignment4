package com.example.bottomsheet.presenter;

public interface PresenterContract {

    void initializeRetrofit();
}
