package com.example.bottomsheet.presenter;

import com.example.bottomsheet.ViewContract;
import com.example.bottomsheet.model.ParkingApi;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Presenter implements PresenterContract{

    ViewContract view;
    ParkingApi api;

    public Presenter(ViewContract viewContract){
        this.view = viewContract;
    }

    @Override
    public void initializeRetrofit() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://ridecellparking.herokuapp.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        api = retrofit.create(ParkingApi.class);
    }
}
